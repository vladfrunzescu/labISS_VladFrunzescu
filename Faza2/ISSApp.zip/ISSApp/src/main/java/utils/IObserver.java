package utils;

import domain.Sarcina;

public interface IObserver {
    void update(Sarcina sarcina);
}
