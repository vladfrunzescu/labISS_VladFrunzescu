package domain;

public enum Status {
    NEINCEPUTA, IN_CURS, FINALIZATA;
}
