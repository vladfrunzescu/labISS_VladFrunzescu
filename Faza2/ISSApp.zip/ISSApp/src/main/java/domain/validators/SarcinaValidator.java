package domain.validators;

public class SarcinaValidator {
}
